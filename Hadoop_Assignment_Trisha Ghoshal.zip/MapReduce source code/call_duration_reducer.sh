#!/bin/bash
awk '{
    sum[$1] += $2
}
END {
    for(id in sum)
        print id "\t" sum[id]
}'

