#!/bin/bash
# Reducer to sum up call type counts

awk '
{
    key=$1
    count=$2
    sum[key] += count
}
END {
    for (k in sum) {
        print k "\t" sum[k]
    }
}'
