#!/bin/bash
awk '{ count[$1] += $2 } END { for (h in count) print h "\t" count[h] }'

