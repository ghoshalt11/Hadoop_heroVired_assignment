#!/bin/bash

# Skip header and extract day/eve/night call counts
awk -F',' 'NR>1 {
    day_calls   = $5
    eve_calls   = $8
    night_calls = $11

    # Emit "Day" once for each call
    for(i=0;i<day_calls;i++)
        print "Day\t1"

    # Emit "Evening" once for each call
    for(i=0;i<eve_calls;i++)
        print "Evening\t1"

    # Emit "Night" once for each call
    for(i=0;i<night_calls;i++)
        print "Night\t1"
}'

