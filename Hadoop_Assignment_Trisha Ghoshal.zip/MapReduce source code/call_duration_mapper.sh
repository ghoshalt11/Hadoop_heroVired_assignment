#!/bin/bash
awk -F',' 'NR>1 {
    caller=$1
    day=$5
    eve=$8
    night=$11
    intl=$14
    total=day+eve+night+intl
    print caller "\t" total
}'

