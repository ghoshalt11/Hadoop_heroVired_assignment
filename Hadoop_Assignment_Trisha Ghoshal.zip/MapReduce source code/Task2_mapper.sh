#!/bin/bash
# Mapper for counting call types

# Skip header using NR>1
awk -F',' 'NR>1 {
  
  day=$5;     # Day Calls
  eve=$8;     # Night Calls
  night=$11;  #  Intl Calls
  intl=$14
 

  for(i=0;i<day;i++)   print "Local_Day_calls\t1";
  for(i=0;i<eve;i++)   print "Local_eve_calls\t1";
  for(i=0;i<night;i++) print "Local_Night_calls\t1";
  for(i=0;i<intl;i++)  print "ISD_calls\t1";

}'
